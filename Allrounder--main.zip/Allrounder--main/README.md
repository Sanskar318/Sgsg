Hi, I’m Allrounder! 🔥

Welcome to the most highly anticipated repository for cricket lovers and live sports enthusiasts!

In this repo, we bring you:

All Asia Cup channels and live streams

Upcoming events and matches, all in one place

A seamless, modern UI, inspired by Hotstar, designed for ease of use and smooth navigation


Our goal is to make watching live sports online effortless and enjoyable. Whether you’re following your favorite team or catching up on upcoming tournaments, this repo has got you covered.

Join our journey, explore the content, and experience premium live streaming like never before!

